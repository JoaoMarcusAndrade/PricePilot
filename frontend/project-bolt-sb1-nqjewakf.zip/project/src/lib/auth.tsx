import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

export type DemoUser = {
  id: string;
  email: string;
};

export type Profile = {
  id: string;
  full_name: string;
  phone: string | null;
  avatar_url: string | null;
};

type StoredAccount = { user: DemoUser; profile: Profile; password: string };
type AuthContextValue = {
  user: DemoUser | null;
  profile: Profile | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (name: string, email: string, password: string) => Promise<{ error: string | null }>;
  signInWithGoogle: () => Promise<{ error: string | null }>;
  updateProfile: (changes: Pick<Profile, 'full_name' | 'phone'>) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
};

const ACCOUNT_KEY = 'pricepilot.demo.account';
const SESSION_KEY = 'pricepilot.demo.session';
const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function readAccount(): StoredAccount | null {
  try {
    const value = localStorage.getItem(ACCOUNT_KEY);
    return value ? (JSON.parse(value) as StoredAccount) : null;
  } catch {
    return null;
  }
}

function readSession(): DemoUser | null {
  try {
    const value = localStorage.getItem(SESSION_KEY);
    return value ? (JSON.parse(value) as DemoUser) : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<DemoUser | null>(() => readSession());
  const [profile, setProfile] = useState<Profile | null>(() => {
    const account = readAccount();
    return account && readSession() ? account.profile : null;
  });
  const [loading] = useState(false);

  function persist(account: StoredAccount) {
    localStorage.setItem(ACCOUNT_KEY, JSON.stringify(account));
    localStorage.setItem(SESSION_KEY, JSON.stringify(account.user));
    setUser(account.user);
    setProfile(account.profile);
  }

  async function signIn(email: string, password: string) {
    const account = readAccount();
    if (!account || account.user.email !== email || account.password !== password) {
      return { error: 'E-mail ou senha incorretos.' };
    }
    persist(account);
    return { error: null };
  }

  async function signUp(name: string, email: string, password: string) {
    const existing = readAccount();
    if (existing?.user.email === email) return { error: 'Este e-mail já está cadastrado. Tente entrar.' };
    const newUser: DemoUser = { id: crypto.randomUUID(), email };
    persist({
      user: newUser,
      password,
      profile: { id: newUser.id, full_name: name, phone: null, avatar_url: null },
    });
    return { error: null };
  }

  async function signInWithGoogle() {
    // Este perfil temporário representa o ponto de integração com o provedor futuro.
    const googleUser: DemoUser = { id: 'google-demo-user', email: 'usuario.google@demo.com' };
    persist({
      user: googleUser,
      password: '',
      profile: { id: googleUser.id, full_name: 'Usuário Google', phone: null, avatar_url: null },
    });
    return { error: null };
  }

  async function updateProfile(changes: Pick<Profile, 'full_name' | 'phone'>) {
    const account = readAccount();
    if (!account || !user) return { error: 'Nenhuma conta demonstrativa está ativa.' };
    const updated = { ...account, profile: { ...account.profile, ...changes } };
    localStorage.setItem(ACCOUNT_KEY, JSON.stringify(updated));
    setProfile(updated.profile);
    return { error: null };
  }

  async function signOut() {
    localStorage.removeItem(SESSION_KEY);
    setUser(null);
    setProfile(null);
  }

  useEffect(() => {
    if (!user) setProfile(null);
  }, [user]);

  return <AuthContext.Provider value={{ user, profile, loading, signIn, signUp, signInWithGoogle, updateProfile, signOut }}>{children}</AuthContext.Provider>;
}

// O contexto mantém a interface que o backend futuro poderá substituir sem alterar as telas.
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
